using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MouseCursor : MonoBehaviour, IMessageReceiver {
	public Texture2D yourCursor;  // Your cursor texture
	public int cursorSizeX = 32;  // Your cursor size x
	public int cursorSizeY = 32;  // Your cursor size y
	public bool enabled = true;

	public string EntKey {
		get {
			return "mouse_cursor";
		}
	}
	
	public void Start() {
	    Screen.showCursor = false;
	}
	
	public void Update() {
		if(Application.loadedLevelName == "level1") {
			this.enabled = false;
		} else {
			this.enabled = true;
		}
	}
	
	//Show as gui component, show mouse curser
	public void OnGUI() {
		if(this.enabled == false)
			return;
		GUI.DrawTexture (new Rect(Event.current.mousePosition.x, Event.current.mousePosition.y, this.cursorSizeX, this.cursorSizeY), this.yourCursor);
		
	}

	public void OnMessage(Telegram t) {
		if(t.Message == "disable") {
			this.enabled = false;
		} else if(t.Message == "enable") {
			this.enabled = true;
		}
	}
}