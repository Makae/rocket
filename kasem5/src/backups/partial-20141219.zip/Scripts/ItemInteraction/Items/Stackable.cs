using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Stackable : Item {
	
	public int Amount = 10;
	public string StackGroup = "";
	new public void Awake() {
		base.Awake();
	}

}