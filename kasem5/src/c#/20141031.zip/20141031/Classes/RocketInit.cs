﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class RocketInit : MonoBehaviour, IMessageReceiver {
	private string EntKey = "init_script";
	void Awake() {
		EntityManager.RegisterEntity(this.EntKey, this);
	}
	
	public void OnMessage(Telegram telegram) {

	}

	void Update() {
		if(Input.GetKeyUp("space")) {
			Debug.Log ("Sending new messages to entitites");
			MessageDispatcher md = MessageDispatcher.Instance();
			md.Dispatch(0, this.EntKey, "group:light", "Mei Meschagee");
			md.Dispatch(1, this.EntKey, "group:light", "Mei delöied Meschagee");
		}
	}
}
